'use client'

import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'

const ACTIVITIES = [
  { id: 'cena', label: 'Cena fuori', emoji: '🍽️' },
  { id: 'aperitivo', label: 'Aperitivo', emoji: '🍸' },
  { id: 'cinema', label: 'Cinema', emoji: '🎬' },
  { id: 'museo', label: 'Museo / Mostra', emoji: '🖼️' },
  { id: 'trekking', label: 'Trekking', emoji: '🥾' },
  { id: 'spa', label: 'Spa / Relax', emoji: '🧖' },
  { id: 'concerti', label: 'Concerti / Live', emoji: '🎶' },
  { id: 'giochi', label: 'Serata giochi', emoji: '🎲' },
  { id: 'shopping', label: 'Shopping', emoji: '🛍️' },
  { id: 'lago', label: 'Gita al lago', emoji: '🏞️' },
]

const PLACES = [
  'Milano', 'Como', 'Varese', 'Bergamo', 'Torino',
  'Lago Maggiore', 'Lago di Como', 'Lecco', 'Brescia', 'Verona',
]

const COLORS = [
  '#FFD93D', '#FF6B9D', '#6BCB77', '#4D96FF', '#FF9A3C',
  '#C77DFF', '#00C9A7', '#FF6B6B', '#FFC6FF', '#B5EAD7',
]

function generateDays() {
  const days = []
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  for (let i = 1; i <= 21; i++) {
    const d = new Date(today)
    d.setDate(today.getDate() + i)
    days.push(d)
  }
  return days
}

const formatDate = (d) =>
  d.toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric', month: 'short' })

const isoDate = (d) => d.toISOString().split('T')[0]

// Genera un ID evento corto e leggibile
const generateEventId = (name) => {
  const slug = name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8)
  const rand = Math.random().toString(36).slice(2, 6)
  return `${slug}-${rand}`
}

export default function BecchiamoCI() {
  const [screen, setScreen] = useState('home')
  const [eventId, setEventId] = useState('')
  const [eventName, setEventName] = useState('')
  const [eventInputVal, setEventInputVal] = useState('')
  const [participants, setParticipants] = useState([])
  const [currentUser, setCurrentUser] = useState(null)
  const [userName, setUserName] = useState('')
  const [selectedDates, setSelectedDates] = useState([])
  const [selectedActivities, setSelectedActivities] = useState([])
  const [selectedPlaces, setSelectedPlaces] = useState([])
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [copied, setCopied] = useState(false)

  const days = generateDays()
  const weeks = []
  for (let i = 0; i < days.length; i += 7) weeks.push(days.slice(i, i + 7))

  // Carica partecipanti dal DB
  const loadParticipants = useCallback(async (eid) => {
    if (!eid) return
    setLoading(true)
    const { data, error } = await supabase
      .from('participants')
      .select('*')
      .eq('event_id', eid)
      .order('created_at', { ascending: true })
    if (!error && data) setParticipants(data)
    setLoading(false)
  }, [])

  // Leggi eventId dall'URL al caricamento
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const eid = params.get('event')
    const ename = params.get('name')
    if (eid && ename) {
      setEventId(eid)
      setEventName(decodeURIComponent(ename))
      loadParticipants(eid)
      setScreen('home')
    }
  }, [loadParticipants])

  const toggleDate = (d) => {
    const key = isoDate(d)
    setSelectedDates((p) => p.includes(key) ? p.filter((x) => x !== key) : [...p, key])
  }
  const toggleActivity = (id) =>
    setSelectedActivities((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id])
  const togglePlace = (pl) =>
    setSelectedPlaces((p) => p.includes(pl) ? p.filter((x) => x !== pl) : [...p, pl])

  const handleCreateEvent = async () => {
    if (!eventInputVal.trim()) return
    const name = eventInputVal.trim()
    const eid = generateEventId(name)
    setEventId(eid)
    setEventName(name)
    // Aggiorna URL senza ricaricare la pagina
    const newUrl = `${window.location.pathname}?event=${eid}&name=${encodeURIComponent(name)}`
    window.history.pushState({}, '', newUrl)
    setScreen('home')
  }

  const handleJoin = () => {
    if (!userName.trim()) return
    const color = COLORS[participants.length % COLORS.length]
    setCurrentUser({ name: userName.trim(), color })
    setSelectedDates([])
    setSelectedActivities([])
    setSelectedPlaces([])
    setStep(1)
    setScreen('fill')
  }

  const handleSave = async () => {
    setSaving(true)
    const { error } = await supabase.from('participants').insert({
      event_id: eventId,
      name: currentUser.name,
      color: currentUser.color,
      dates: selectedDates,
      activities: selectedActivities,
      places: selectedPlaces,
    })
    if (!error) {
      await loadParticipants(eventId)
      setCurrentUser(null)
      setUserName('')
      setScreen('view')
    } else {
      alert('Errore nel salvataggio 😢 Riprova!')
    }
    setSaving(false)
  }

  const handleNewEvent = () => {
    setEventName('')
    setEventId('')
    setEventInputVal('')
    setParticipants([])
    setCurrentUser(null)
    setUserName('')
    window.history.pushState({}, '', window.location.pathname)
    setScreen('home')
  }

  const copyLink = () => {
    const url = `${window.location.origin}${window.location.pathname}?event=${eventId}&name=${encodeURIComponent(eventName)}`
    navigator.clipboard.writeText(url)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const getMatches = () => {
    if (participants.length < 2) return null
    const dateCount = {}, actCount = {}, placeCount = {}
    participants.forEach((p) => {
      (p.dates || []).forEach((d) => { dateCount[d] = (dateCount[d] || 0) + 1 })
      (p.activities || []).forEach((a) => { actCount[a] = (actCount[a] || 0) + 1 })
      (p.places || []).forEach((pl) => { placeCount[pl] = (placeCount[pl] || 0) + 1 })
    })
    return {
      commonDates: Object.entries(dateCount)
        .filter(([, c]) => c === participants.length).map(([d]) => d).sort(),
      commonActivities: Object.entries(actCount)
        .filter(([, c]) => c >= Math.ceil(participants.length / 2))
        .sort((a, b) => b[1] - a[1]).map(([id, count]) => ({ id, count })),
      commonPlaces: Object.entries(placeCount)
        .filter(([, c]) => c >= Math.ceil(participants.length / 2))
        .sort((a, b) => b[1] - a[1]).map(([place, count]) => ({ place, count })),
    }
  }

  const matches = getMatches()

  // ── Palette ──
  const CARD   = 'rgba(255,255,255,0.06)'
  const BORDER = 'rgba(255,255,255,0.12)'
  const ACCENT = '#FFD93D'
  const ACCENT2 = '#FF6BCD'
  const TEXT   = '#F3EEFF'
  const MUTED  = 'rgba(243,238,255,0.45)'

  const s = {
    app: {
      minHeight: '100vh',
      background: 'linear-gradient(145deg, #2D0057 0%, #1A003A 60%, #3D005A 100%)',
      color: TEXT, fontFamily: "'Syne', sans-serif",
      overflowX: 'hidden', position: 'relative',
    },
    chickenBg: {
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      pointerEvents: 'none', zIndex: 0, overflow: 'hidden',
    },
    header: {
      padding: '20px 24px 16px',
      borderBottom: `1px solid ${BORDER}`,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      position: 'relative', zIndex: 1,
    },
    logo: {
      fontSize: '22px', fontWeight: '800', letterSpacing: '-0.02em',
      color: TEXT, display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer',
    },
    pill: {
      background: 'rgba(255,255,255,0.1)', border: `1px solid ${BORDER}`,
      borderRadius: '100px', padding: '5px 12px', fontSize: '12px',
      color: MUTED, letterSpacing: '0.04em', fontFamily: 'monospace',
    },
    content: {
      maxWidth: '620px', margin: '0 auto',
      padding: '28px 20px 80px', position: 'relative', zIndex: 1,
    },
    h1: {
      fontSize: 'clamp(28px, 8vw, 50px)', lineHeight: '1.08',
      marginBottom: '14px', fontWeight: '800', letterSpacing: '-0.03em',
    },
    sub: { color: MUTED, fontSize: '15px', marginBottom: '28px', lineHeight: '1.65' },
    card: {
      background: CARD, border: `1px solid ${BORDER}`, borderRadius: '20px',
      padding: '22px', marginBottom: '14px', backdropFilter: 'blur(12px)',
    },
    input: {
      width: '100%', background: 'rgba(0,0,0,0.25)', border: `1px solid ${BORDER}`,
      borderRadius: '12px', padding: '14px 16px', color: TEXT, fontSize: '16px',
      fontFamily: "'Syne', sans-serif", outline: 'none', boxSizing: 'border-box',
      marginBottom: '14px', fontWeight: '600',
    },
    btn: {
      display: 'block', width: '100%', padding: '15px',
      background: ACCENT, color: '#1A0030', border: 'none',
      borderRadius: '14px', fontSize: '15px', fontWeight: '800',
      cursor: 'pointer', fontFamily: "'Syne', sans-serif",
      transition: 'transform 0.1s, opacity 0.2s',
    },
    btnSec: {
      display: 'block', width: '100%', padding: '13px',
      background: 'transparent', color: MUTED, border: `1px solid ${BORDER}`,
      borderRadius: '14px', fontSize: '14px', cursor: 'pointer',
      fontFamily: "'Syne', sans-serif", marginTop: '10px',
    },
    btnCopy: {
      display: 'block', width: '100%', padding: '13px',
      background: copied ? 'rgba(107,203,119,0.2)' : 'rgba(255,255,255,0.08)',
      color: copied ? '#6BCB77' : TEXT,
      border: copied ? '1px solid #6BCB77' : `1px solid ${BORDER}`,
      borderRadius: '14px', fontSize: '14px', cursor: 'pointer',
      fontFamily: "'Syne', sans-serif", marginTop: '10px', fontWeight: '700',
      transition: 'all 0.2s',
    },
    label: {
      fontSize: '10px', letterSpacing: '0.15em', textTransform: 'uppercase',
      color: MUTED, marginBottom: '12px', fontWeight: '700',
    },
    stepBar: { display: 'flex', gap: '6px', marginBottom: '26px' },
    stepDot: (a, d) => ({
      height: '4px', flex: 1, borderRadius: '2px',
      background: (a || d) ? ACCENT : BORDER, opacity: d ? 0.4 : 1,
    }),
    dayGrid: { display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '5px' },
    dayCell: (sel, wknd) => ({
      aspectRatio: '1', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', borderRadius: '10px',
      cursor: 'pointer',
      background: sel ? ACCENT : wknd ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.04)',
      border: sel ? 'none' : `1px solid ${BORDER}`,
      transition: 'all 0.15s',
    }),
    dcLabel: (sel) => ({ fontSize: '9px', color: sel ? '#1A0030' : MUTED, fontWeight: '700' }),
    dcNum:   (sel) => ({ fontSize: '14px', fontWeight: '800', color: sel ? '#1A0030' : TEXT }),
    actGrid: { display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px' },
    actItem: (sel) => ({
      padding: '12px 13px', borderRadius: '12px',
      border: sel ? `1.5px solid ${ACCENT}` : `1px solid ${BORDER}`,
      background: sel ? 'rgba(255,217,61,0.12)' : 'rgba(255,255,255,0.04)',
      cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '9px',
      fontSize: '13px', color: sel ? ACCENT : MUTED, fontWeight: sel ? '700' : '500',
      transition: 'all 0.15s',
    }),
    placeWrap: { display: 'flex', flexWrap: 'wrap', gap: '8px' },
    placeChip: (sel) => ({
      padding: '8px 16px', borderRadius: '100px',
      border: sel ? `1.5px solid ${ACCENT2}` : `1px solid ${BORDER}`,
      background: sel ? 'rgba(255,107,205,0.15)' : 'rgba(255,255,255,0.05)',
      cursor: 'pointer', fontSize: '13px',
      color: sel ? ACCENT2 : MUTED, fontWeight: sel ? '700' : '500',
      transition: 'all 0.15s',
    }),
    matchCard: {
      background: 'rgba(0,0,0,0.2)', border: `1px solid ${BORDER}`,
      borderRadius: '16px', padding: '18px', marginBottom: '12px',
    },
    matchTitle: {
      fontSize: '10px', color: MUTED, letterSpacing: '0.1em',
      textTransform: 'uppercase', marginBottom: '10px', fontWeight: '700',
    },
    matchRow: {
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '9px 0', borderBottom: `1px solid rgba(255,255,255,0.06)`,
    },
    matchLabel: { fontSize: '14px', color: TEXT, fontWeight: '600' },
    badge: (n, tot) => ({
      fontSize: '11px', padding: '3px 10px', borderRadius: '100px', fontFamily: 'monospace',
      background: n === tot ? ACCENT : 'rgba(255,255,255,0.08)',
      color: n === tot ? '#1A0030' : MUTED,
      border: n === tot ? 'none' : `1px solid ${BORDER}`,
      fontWeight: '700',
    }),
    avatar: (color) => ({
      width: '32px', height: '32px', borderRadius: '50%', background: color,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: '13px', fontWeight: '800', color: '#1A0030', flexShrink: 0,
    }),
    pRow: {
      display: 'flex', alignItems: 'center', gap: '10px',
      padding: '10px 0', borderBottom: `1px solid rgba(255,255,255,0.06)`,
    },
    shareBox: {
      background: 'rgba(255,217,61,0.07)', border: `1px solid rgba(255,217,61,0.2)`,
      borderRadius: '14px', padding: '16px', marginBottom: '14px',
    },
  }

  const WD = ['Lu', 'Ma', 'Me', 'Gi', 'Ve', 'Sa', 'Do']

  return (
    <div style={s.app}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        button:hover { opacity: 0.85; }
        button:active { transform: scale(0.97) !important; }
        input::placeholder { color: rgba(243,238,255,0.28); }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        @keyframes floatA { 0%,100%{transform:translateY(0) rotate(-8deg)} 50%{transform:translateY(-18px) rotate(5deg)} }
        @keyframes floatB { 0%,100%{transform:translateY(0) rotate(12deg)} 50%{transform:translateY(-12px) rotate(-4deg)} }
        @keyframes floatC { 0%,100%{transform:translateY(0) rotate(3deg)} 50%{transform:translateY(-22px) rotate(-10deg)} }
        @keyframes floatD { 0%,100%{transform:translateY(0) rotate(-15deg)} 60%{transform:translateY(-10px) rotate(8deg)} }
        .ch-a{animation:floatA 5.2s ease-in-out infinite}
        .ch-b{animation:floatB 4.8s ease-in-out infinite}
        .ch-c{animation:floatC 6.1s ease-in-out infinite}
        .ch-d{animation:floatD 4.3s ease-in-out infinite}
      `}</style>

      {/* Polli fluttuanti */}
      <div style={s.chickenBg}>
        <span className="ch-a" style={{position:'absolute',top:'8%',left:'4%',fontSize:'52px',opacity:0.09}}>🐔</span>
        <span className="ch-b" style={{position:'absolute',top:'14%',right:'6%',fontSize:'38px',opacity:0.08}}>🐓</span>
        <span className="ch-c" style={{position:'absolute',top:'40%',left:'2%',fontSize:'44px',opacity:0.07}}>🐔</span>
        <span className="ch-d" style={{position:'absolute',top:'58%',right:'4%',fontSize:'60px',opacity:0.08}}>🐔</span>
        <span className="ch-a" style={{position:'absolute',bottom:'12%',left:'14%',fontSize:'34px',opacity:0.07}}>🐣</span>
        <span className="ch-b" style={{position:'absolute',bottom:'22%',right:'17%',fontSize:'42px',opacity:0.08}}>🐓</span>
        <span className="ch-c" style={{position:'absolute',top:'74%',left:'44%',fontSize:'28px',opacity:0.06}}>🥚</span>
        <span className="ch-d" style={{position:'absolute',top:'28%',left:'48%',fontSize:'36px',opacity:0.06}}>🐔</span>
      </div>

      {/* HEADER */}
      <div style={s.header}>
        <div style={s.logo} onClick={() => eventId ? setScreen('home') : null}>
          🐔 Becchiamoci
        </div>
        <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
          {participants.length > 0 && (
            <div style={s.pill}>{participants.length} {participants.length === 1 ? 'pollo' : 'polli'}</div>
          )}
          {eventId && (
            <button style={{...s.pill, cursor:'pointer', fontFamily:"'Syne',sans-serif", fontSize:'12px', background:'none', border:`1px solid ${BORDER}`, color:MUTED}} onClick={copyLink}>
              {copied ? '✓ copiato!' : '🔗 condividi'}
            </button>
          )}
        </div>
      </div>

      <div style={s.content}>

        {/* HOME */}
        {screen === 'home' && (
          <>
            <h1 style={s.h1}>
              {eventName ? (
                <>{eventName} 🐔</>
              ) : (
                <>Quando ci<br /><span style={{color:ACCENT}}>becchiamo</span>? 🐔</>
              )}
            </h1>

            {!eventName ? (
              <>
                <p style={s.sub}>
                  Crea un poll-o, ogni amico risponde con le sue disponibilità e l'app trova il momento perfetto per beccarsi.
                </p>
                <div style={s.card}>
                  <p style={s.label}>Dai un nome all'evento</p>
                  <input
                    style={s.input}
                    placeholder="es. Aperitivo estivo 🐔"
                    value={eventInputVal}
                    onChange={(e) => setEventInputVal(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleCreateEvent() }}
                    autoFocus
                  />
                  <button style={s.btn} onClick={handleCreateEvent}>
                    Crea il poll-o 🐔
                  </button>
                </div>
              </>
            ) : (
              <>
                <p style={s.sub}>
                  {participants.length === 0
                    ? 'Poll-o creato! Sei il primo pollo. Aggiungi la tua disponibilità o condividi il link con gli amici.'
                    : `${participants.length} ${participants.length === 1 ? 'pollo ha' : 'polli hanno'} già risposto al poll-o.`}
                </p>

                {/* Box condivisione */}
                <div style={s.shareBox}>
                  <p style={{fontSize:'12px', fontWeight:'800', color:ACCENT, marginBottom:'6px'}}>🔗 Link da condividere</p>
                  <p style={{fontSize:'12px', color:MUTED, lineHeight:'1.5', wordBreak:'break-all', fontFamily:'monospace'}}>
                    {typeof window !== 'undefined' ? `${window.location.origin}?event=${eventId}&name=${encodeURIComponent(eventName)}` : ''}
                  </p>
                  <button style={s.btnCopy} onClick={copyLink}>
                    {copied ? '✓ Link copiato!' : '📋 Copia link da mandare agli amici'}
                  </button>
                </div>

                <button style={s.btn} onClick={() => { setScreen('join'); setUserName('') }}>
                  Rispondi al poll-o 🐔
                </button>

                {participants.length >= 1 && (
                  <button style={s.btnSec} onClick={() => { loadParticipants(eventId); setScreen('view') }}>
                    Vedi i match →
                  </button>
                )}

                <button style={{...s.btnSec, marginTop:'14px', fontSize:'12px', color:'rgba(243,238,255,0.2)', border:`1px solid rgba(255,255,255,0.05)`}} onClick={handleNewEvent}>
                  + Nuovo evento
                </button>
              </>
            )}
          </>
        )}

        {/* JOIN */}
        {screen === 'join' && (
          <>
            <p style={{...s.label, marginBottom:'16px'}}>Rispondi al poll-o</p>
            <h1 style={{...s.h1, fontSize:'30px', marginBottom:'8px'}}>Chi sei, pollo? 🐔</h1>
            <p style={s.sub}>Inserisci il tuo nome per rispondere</p>
            <div style={s.card}>
              <input
                style={s.input}
                placeholder="Il tuo nome..."
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleJoin()}
                autoFocus
              />
              <button style={s.btn} onClick={handleJoin} disabled={!userName.trim()}>
                Avanti 🐔
              </button>
              <button style={s.btnSec} onClick={() => setScreen('home')}>← Indietro</button>
            </div>
          </>
        )}

        {/* FILL */}
        {screen === 'fill' && currentUser && (
          <>
            <div style={{display:'flex',alignItems:'center',gap:'12px',marginBottom:'22px'}}>
              <div style={s.avatar(currentUser.color)}>{currentUser.name[0].toUpperCase()}</div>
              <div>
                <p style={{fontSize:'17px',fontWeight:'800'}}>{currentUser.name} 🐔</p>
                <p style={{fontSize:'12px',color:MUTED}}>domanda {step} di 3</p>
              </div>
            </div>

            <div style={s.stepBar}>
              {[1,2,3].map((n) => <div key={n} style={s.stepDot(step===n, step>n)} />)}
            </div>

            {step === 1 && (
              <>
                <h2 style={{fontSize:'22px',fontWeight:'800',marginBottom:'6px'}}>Quando ci becchiamo? 📅</h2>
                <p style={s.sub}>Tocca i giorni in cui sei disponibile</p>
                <div style={s.card}>
                  <div style={{...s.dayGrid,marginBottom:'4px'}}>
                    {WD.map((l) => (
                      <div key={l} style={{textAlign:'center',fontSize:'9px',color:MUTED,fontWeight:'700',letterSpacing:'0.06em',paddingBottom:'4px'}}>
                        {l}
                      </div>
                    ))}
                  </div>
                  {weeks.map((week, wi) => (
                    <div key={wi} style={{...s.dayGrid,marginBottom:'5px'}}>
                      {week.map((day) => {
                        const key = isoDate(day)
                        const sel = selectedDates.includes(key)
                        const dow = day.getDay()
                        return (
                          <div key={key} style={s.dayCell(sel, dow===0||dow===6)} onClick={() => toggleDate(day)}>
                            <span style={s.dcLabel(sel)}>{day.toLocaleDateString('it-IT',{weekday:'narrow'})}</span>
                            <span style={s.dcNum(sel)}>{day.getDate()}</span>
                          </div>
                        )
                      })}
                    </div>
                  ))}
                  <p style={{fontSize:'11px',color:MUTED,marginTop:'8px',fontFamily:'monospace'}}>
                    {selectedDates.length} {selectedDates.length === 1 ? 'data' : 'date'} selezionate
                  </p>
                </div>
                <button style={s.btn} onClick={() => setStep(2)}>Continua → Cosa fare</button>
              </>
            )}

            {step === 2 && (
              <>
                <h2 style={{fontSize:'22px',fontWeight:'800',marginBottom:'6px'}}>Cosa becchetti volentieri? 🎯</h2>
                <p style={s.sub}>Seleziona una o più attività</p>
                <div style={s.card}>
                  <div style={s.actGrid}>
                    {ACTIVITIES.map((a) => (
                      <div key={a.id} style={s.actItem(selectedActivities.includes(a.id))} onClick={() => toggleActivity(a.id)}>
                        <span style={{fontSize:'19px'}}>{a.emoji}</span>
                        <span>{a.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <button style={s.btn} onClick={() => setStep(3)}>Continua → Dove</button>
                <button style={s.btnSec} onClick={() => setStep(1)}>← Date</button>
              </>
            )}

            {step === 3 && (
              <>
                <h2 style={{fontSize:'22px',fontWeight:'800',marginBottom:'6px'}}>Dove ti va di volare? 📍</h2>
                <p style={s.sub}>Seleziona le zone che preferisci</p>
                <div style={s.card}>
                  <div style={s.placeWrap}>
                    {PLACES.map((p) => (
                      <div key={p} style={s.placeChip(selectedPlaces.includes(p))} onClick={() => togglePlace(p)}>
                        {p}
                      </div>
                    ))}
                  </div>
                </div>
                <button style={{...s.btn, opacity: saving ? 0.6 : 1}} onClick={handleSave} disabled={saving}>
                  {saving ? 'Salvando... 🐔' : '✓ Invia risposta 🐔'}
                </button>
                <button style={s.btnSec} onClick={() => setStep(2)}>← Attività</button>
              </>
            )}
          </>
        )}

        {/* VIEW */}
        {screen === 'view' && (
          <>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:'22px'}}>
              <div>
                <h1 style={{fontSize:'24px',fontWeight:'800',marginBottom:'4px'}}>{eventName}</h1>
                <p style={{color:MUTED,fontSize:'13px'}}>
                  {loading ? 'Caricando i polli...' : `${participants.length} 🐔 ${participants.length === 1 ? 'risposta' : 'risposte'}`}
                </p>
              </div>
              <div style={{display:'flex',gap:'8px'}}>
                <button style={{...s.btn,width:'auto',padding:'9px 14px',fontSize:'13px'}} onClick={() => { loadParticipants(eventId) }}>
                  ↻
                </button>
                <button style={{...s.btn,width:'auto',padding:'9px 16px',fontSize:'13px'}} onClick={() => { setScreen('join'); setUserName('') }}>
                  + Pollo
                </button>
              </div>
            </div>

            {/* Link condivisione */}
            <button style={s.btnCopy} onClick={copyLink}>
              {copied ? '✓ Link copiato!' : '🔗 Copia link da mandare agli amici'}
            </button>

            {/* Pollaio */}
            <div style={{...s.card, marginTop:'14px'}}>
              <p style={s.label}>Il pollaio 🐔</p>
              {loading ? (
                <p style={{color:MUTED,fontSize:'14px',padding:'8px 0'}}>Caricando... 🐔</p>
              ) : participants.map((p) => (
                <div key={p.id} style={s.pRow}>
                  <div style={s.avatar(p.color)}>{p.name[0].toUpperCase()}</div>
                  <div style={{flex:1,fontSize:'15px',fontWeight:'700'}}>{p.name}</div>
                  <div style={{display:'flex',gap:'8px'}}>
                    <span style={{fontSize:'11px',color:MUTED,fontFamily:'monospace'}}>{(p.dates||[]).length}gg</span>
                    <span style={{fontSize:'11px',color:MUTED,fontFamily:'monospace'}}>{(p.activities||[]).length} att.</span>
                  </div>
                </div>
              ))}
            </div>

            {participants.length >= 2 ? (
              <>
                <p style={{fontSize:'12px',color:ACCENT,letterSpacing:'0.12em',textTransform:'uppercase',fontWeight:'800',margin:'22px 0 14px'}}>
                  🐔 Match trovati
                </p>

                <div style={s.matchCard}>
                  <p style={s.matchTitle}>📅 Quando ci becchiamo ({matches?.commonDates.length || 0})</p>
                  {matches?.commonDates.length > 0
                    ? matches.commonDates.slice(0,6).map((d) => {
                        const date = new Date(d + 'T00:00:00')
                        return (
                          <div key={d} style={s.matchRow}>
                            <span style={s.matchLabel}>{formatDate(date)}</span>
                            <span style={s.badge(participants.length,participants.length)}>tutti ✓</span>
                          </div>
                        )
                      })
                    : <p style={{color:MUTED,fontSize:'13px',padding:'8px 0'}}>Nessuna data in comune ancora. Aggiungete più polli! 🐣</p>
                  }
                </div>

                <div style={s.matchCard}>
                  <p style={s.matchTitle}>🎯 Cosa becchettare</p>
                  {matches?.commonActivities.length > 0
                    ? matches.commonActivities.map(({id,count}) => {
                        const act = ACTIVITIES.find((a) => a.id === id)
                        return (
                          <div key={id} style={s.matchRow}>
                            <span style={s.matchLabel}>{act?.emoji} {act?.label}</span>
                            <span style={s.badge(count,participants.length)}>{count}/{participants.length}</span>
                          </div>
                        )
                      })
                    : <p style={{color:MUTED,fontSize:'13px',padding:'8px 0'}}>Nessuna attività in comune.</p>
                  }
                </div>

                <div style={s.matchCard}>
                  <p style={s.matchTitle}>📍 Dove volare</p>
                  {matches?.commonPlaces.length > 0
                    ? matches.commonPlaces.map(({place,count}) => (
                        <div key={place} style={s.matchRow}>
                          <span style={s.matchLabel}>{place}</span>
                          <span style={s.badge(count,participants.length)}>{count}/{participants.length}</span>
                        </div>
                      ))
                    : <p style={{color:MUTED,fontSize:'13px',padding:'8px 0'}}>Nessun luogo in comune.</p>
                  }
                </div>
              </>
            ) : (
              <div style={{...s.card,textAlign:'center',padding:'44px 20px'}}>
                <p style={{fontSize:'48px',marginBottom:'12px'}}>🐔</p>
                <p style={{fontSize:'16px',fontWeight:'800',marginBottom:'6px'}}>Serve almeno un altro pollo</p>
                <p style={{fontSize:'13px',color:MUTED}}>Copia il link qui sopra e mandalo agli amici.</p>
              </div>
            )}

            <button style={{...s.btnSec,marginTop:'22px'}} onClick={() => setScreen('home')}>← Home</button>
          </>
        )}
      </div>
    </div>
  )
}
